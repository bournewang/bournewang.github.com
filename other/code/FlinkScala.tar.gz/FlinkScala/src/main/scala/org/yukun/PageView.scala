package org.yukun

import org.apache.flink.api.scala.createTypeInformation
import org.apache.flink.streaming.api.TimeCharacteristic
import org.apache.flink.streaming.api.functions.AssignerWithPeriodicWatermarks
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.streaming.api.windowing.time.Time

object PageView {
  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment
    env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime)
    env.setParallelism(1)

    env.readTextFile("./data/data1.log")
      .map(Utils.string2UserBehavior(_))
      .assignTimestampsAndWatermarks(new EventTimeExtractor)
      .filter(_.behavior == "P")
      .map(data => ("P", 1))
      .timeWindowAll(Time.seconds(10))
      .sum(1)
      .print()

    env.execute("Page View")
  }
}
