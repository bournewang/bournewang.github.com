package org.yukun

import org.apache.flink.streaming.api.functions.AssignerWithPeriodicWatermarks
import org.apache.flink.streaming.api.watermark.Watermark

class EventTimeExtractor extends AssignerWithPeriodicWatermarks[UserBehavior] {
  var currentMaxEventTime = 0L;
  val maxOutOfOrderness = 10;
  override def getCurrentWatermark: Watermark = {
    new Watermark((currentMaxEventTime - maxOutOfOrderness) * 1000)
  }

  override def extractTimestamp(t: UserBehavior, l: Long): Long = {
    val timeStamp = t.timeStamp * 1000
    currentMaxEventTime = Math.max(timeStamp, currentMaxEventTime)
    timeStamp
  }
}