package org.yukun

import org.apache.flink.api.common.functions.AggregateFunction
import org.apache.flink.api.common.state.{ListState, ListStateDescriptor}
import org.apache.flink.api.scala.createTypeInformation
import org.apache.flink.configuration.Configuration
import org.apache.flink.streaming.api.TimeCharacteristic
import org.apache.flink.streaming.api.functions.{AssignerWithPeriodicWatermarks, KeyedProcessFunction}
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.streaming.api.scala.function.WindowFunction
import org.apache.flink.streaming.api.watermark.Watermark
import org.apache.flink.streaming.api.windowing.time.Time
import org.apache.flink.streaming.api.windowing.windows.TimeWindow
import org.apache.flink.util.Collector

import java.sql.Timestamp
import scala.collection.mutable.ListBuffer

object HotProduct {



  case class ProductViewCount(productId: Long, windowEnd:Long, count: Long)

  def main(args: Array[String]): Unit = {
    println("hello world!")
    val env = StreamExecutionEnvironment.getExecutionEnvironment
    env.setParallelism(1)
    env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime)
    env.readTextFile("./data/data1.log")
      .map(Utils.string2UserBehavior(_))
      .assignTimestampsAndWatermarks(new EventTimeExtractor)
      .filter(_.behavior == "P")
      .keyBy(_.productId)
      .timeWindow(Time.hours(1), Time.minutes(5))
      .aggregate(new CountProduct, new WindowResult)
      .keyBy(_.windowEnd)
      .process(new TopHotProduct(3))
      .print

    env.execute("Hot Products ...")
  }

  class TopHotProduct(topN: Int) extends KeyedProcessFunction[Long, ProductViewCount, String] {
    private var productState:ListState[ProductViewCount] = _

    override def open(parameters: Configuration): Unit = {
      productState = getRuntimeContext.getListState(
        new ListStateDescriptor[ProductViewCount](
          "product-state",
          classOf[ProductViewCount]
        )
      )
    }

    override def processElement(i: ProductViewCount,
                                context: KeyedProcessFunction[Long, ProductViewCount, String]#Context,
                                collector: Collector[String]): Unit = {
      productState.add(i)
      context.timerService().registerEventTimeTimer(i.windowEnd + 1)
    }

    override def onTimer(timestamp: Long,
                         ctx: KeyedProcessFunction[Long, ProductViewCount, String]#OnTimerContext,
                         out: Collector[String]): Unit = {
      val allProduct:ListBuffer[ProductViewCount] = new ListBuffer[ProductViewCount]
      val iterable = productState.get.iterator()
      while (iterable.hasNext) {
        allProduct += iterable.next()
      }

      val sortedProducts = allProduct.sortWith(_.count > _.count).take(topN)
      productState.clear()

      val sb = new StringBuilder
      sb.append("Time: " + (new Timestamp(timestamp - 1)) + "\n")
      sortedProducts.foreach(product => {
        sb.append("product Id: "+product.productId +", access: " + product.count + "\n")
      })

      sb.append("===================")
      out.collect(sb.toString())
    }
  }
  class CountProduct extends AggregateFunction[UserBehavior, Long, Long] {
    override def createAccumulator(): Long = 0L

    override def add(in: UserBehavior, acc: Long): Long = acc + 1

    override def getResult(acc: Long): Long = acc

    override def merge(acc: Long, acc1: Long): Long = acc + acc1
  }

  class WindowResult extends WindowFunction[Long, ProductViewCount, Long,TimeWindow] {
    override def apply(key: Long,
                       window: TimeWindow,
                       input: Iterable[Long],
                       out: Collector[ProductViewCount]): Unit = {
      out.collect(ProductViewCount(key, window.getEnd, input.iterator.next()))
    }
  }

}
