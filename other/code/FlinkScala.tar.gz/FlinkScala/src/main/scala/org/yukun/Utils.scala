package org.yukun

import java.text.SimpleDateFormat

object Utils {
  def string2UserBehavior(line:String):UserBehavior ={
    val fields = line.split(",")
    UserBehavior(
      fields(0).trim.toLong,
      fields(1).trim.toLong,
      fields(2).trim.toLong,
      fields(3).trim,
      fields(4).trim.toLong,
      fields(5).trim
    )
  }

  def string2ApacheLogEvent(line: String): ApacheLogEvent = {
    val fields = line.split(" ")
    val dateFormat = new SimpleDateFormat("dd/MM/yyyy:HH:mm:ss")
    val timeStamp = dateFormat.parse(fields(3).trim).getTime
    ApacheLogEvent(fields(0).trim, fields(1).trim, timeStamp,
      fields(5).trim, fields(6).trim)
  }
}
