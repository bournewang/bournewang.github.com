package org.yukun

case class UserBehavior(
                         userId: Long,
                         productId: Long,
                         categoryId: Long,
                         behavior: String,
                         timeStamp: Long,
                         sessionId: String
                       )