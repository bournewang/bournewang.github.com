package org.yukun;

import org.omg.CORBA.PUBLIC_MEMBER;

import java.io.Serializable;
import java.sql.Types;

public class Config implements Serializable {
    public static final String DRIVER_CLASS = "com.mysql.jdbc.Driver";
    public static final String DB_URL = "jdbc:mysql://hadoop001:3306/mall?useUnicode=true&characterEncoding=utf8";
    public static final String USERNAME = "root";
    public static final String PASSWORD = "yukun@2022";
    public static final int BATCH_SIZE = 2;
}
