package org.yukun

import scala.util.parsing.json.JSON
import org.apache.flink.api.common.functions.RichMapFunction
import org.apache.flink.util.StringUtils

class UserMapFunction extends RichMapFunction[String, UserModel] {
  override def map(in: String): UserModel = {
//    println("raw data: " + in)
    if (StringUtils.isNullOrWhitespaceOnly(in)) {
      return null
    }
    try {
      val jsonS = JSON.parseFull(in)
      jsonS match {
        case Some(obj: Map[String, String]) => {
          val u = new UserModel(obj.getOrElse("RNAME", ""),
            obj.getOrElse("SEX", ""),
            String.valueOf(obj.getOrElse("AGE", "")),
            String.valueOf(obj.getOrElse("BIRTHDAY", "")),
            obj.getOrElse("BPLACE", "")
          )
          u
        }
        case _ => null
      }
    }catch{
      case _ => null
    }
  }
}


