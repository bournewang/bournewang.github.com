package org.yukun

import org.apache.flink.api.common.state.MapStateDescriptor
import org.apache.flink.api.common.state.MapState
import org.apache.flink.configuration.Configuration
import org.apache.flink.shaded.netty4.io.netty.util.internal.StringUtil
import org.apache.flink.streaming.api.scala.function.ProcessAllWindowFunction
import org.apache.flink.streaming.api.windowing.windows.TimeWindow
import org.apache.flink.util.Collector

import scala.collection.mutable

class UserProcessFunction extends ProcessAllWindowFunction[UserModel, String, TimeWindow] {
  var provincesState:MapState[String, Int] = null
  var sexState:MapState[String, Int] = null
  var ageState:MapState[String, Int] = null

  override def open(parameters: Configuration): Unit = {
    val provinceDesc = new MapStateDescriptor[String, Int]("provincesState", classOf[String], classOf[Int])
    val sexDesc = new MapStateDescriptor[String, Int]("sexState", classOf[String], classOf[Int])
    val ageDesc = new MapStateDescriptor[String, Int]("ageState", classOf[String], classOf[Int])
//
    provincesState = getRuntimeContext.getMapState(provinceDesc)
    sexState = getRuntimeContext.getMapState(sexDesc)
    ageState = getRuntimeContext.getMapState(ageDesc)
  }

  override def process(context: Context, elements: Iterable[UserModel], out: Collector[String]): Unit = {
    var user:UserModel = null
    for ( user <- elements ) {
//      println(user.toString)
      if (user != null) {
        val province = user.province
        if (!StringUtil.isNullOrEmpty(province)) {
          provincesState.put(province, provincesState.get(province)+1)
        }

        val sex = user.sex
        if (!StringUtil.isNullOrEmpty(sex)) {
          sexState.put(sex, sexState.get(sex)+1)
        }

        val age_group = user.age_group
        if (!StringUtil.isNullOrEmpty(age_group)) {
          ageState.put(age_group, ageState.get(age_group)+1)
        }
      }
    }

    // get top 5 provinces
    println("----------")
    var output:String = ""
    output += getStateString(provincesState) + "\n"
    output += getStateString(sexState) + "\n"
    output += getStateString(ageState)
    out.collect(output)
  }

  def getStateString(state: MapState[String, Int]): String = {
    if (!state.isEmpty) {
      val iterator = state.entries().iterator()
      var map = new mutable.HashMap [String, Int]
      while (iterator.hasNext) {
        val item = iterator.next()
        map += (item.getKey -> item.getValue)
      }
      map.toList.sortBy(-_._2).toString() //.take(10)
    }else{
      ""
    }
  }
}
