package org.yukun

import org.apache.flink.api.scala.createTypeInformation
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.streaming.api.windowing.assigners.TumblingProcessingTimeWindows
import org.apache.flink.streaming.api.windowing.time.Time

object UserReport {
  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment
    val stream = env.addSource(UserSource).setParallelism(1)
    var result = stream
      .map(new UserMapFunction())
      .windowAll(TumblingProcessingTimeWindows.of(Time.seconds(2)))
      .process(new UserProcessFunction())

      result.print
    env.execute("Realtime User Analyse ...")
  }
}
