package org.yukun

class UserModel(na: String, se: String, ag: String, bd: String, bp: String) {
  var name:String = na
  var sex:String = se
  var age:String = ag
  var birthday:String = bd
  var birth_place:String = bp
  var province: String = getProvince(bp)
  var age_group: String = getAgeGroup(ag)

  def getProvince(addr: String): String = {
    try {
      val p = "^(.*省|.*自治区|.*市).*".r
      val p(province) = addr
      province
    }catch{
      case _ => ""
    }
  }

  def getAgeGroup(ag: String): String = {
    try {
      val a = (ag.toDouble.toInt / 10) * 10
      if (a == 0) {
        "0-9"
      } else {
        a.toString + "s"
      }
    }catch{
      case _ => ""
    }
  }

  override def toString = s"UserModel(name=$name, sex=$sex, age=$age, age_group=$age_group, birthday=$birthday, birth_place=$birth_place, province=$province)"
}

//{"AGE":48,"BIRTHDAY":"1973","BPLACE":"吉林省吉林市磐石县",
// "IDTYPE":"01","RNAME":"崔**","SEX":"女"}
