package org.yukun

import org.apache.flink.streaming.api.functions.source.SourceFunction

import java.io.{File, BufferedReader, FileReader}

object UserSource extends SourceFunction[String]{
  override
  def run(sourceContext: SourceFunction.SourceContext[String]): Unit = {
    try {
      val input = "./data/person_info_1000.json"
      val fp = new File(input)
      val reader = new BufferedReader(new FileReader(fp));
      var line: String = reader.readLine();
      var i = 0;
      while (line != null) {
//        println("+++++ " + i +", " + line)
        i+=1
        sourceContext.collect(line);
        Thread.sleep(20);
        line = reader.readLine();
      }
    } catch{
      case e:Exception => e.printStackTrace()
      case _ => ""
    }
  }

  override def cancel(): Unit = {

  }

  def main(args: Array[String]): Unit = {
    UserSource.run(null)
  }
}
