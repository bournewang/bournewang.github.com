package org.yukun

import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.{udf, when}

object UserReport {
  def main(args: Array[String]): Unit = {
    println("hello user report");
    if (args.length < 1) {
      println(
        """
          |Usage: org.yukun.UserReport <data-path>
          |""".stripMargin)
      System.exit(0)
    }

    val Array(dataPath) = args
    val conf = new SparkConf()
    conf.setAppName("User Report")
    conf.setMaster("local")
    val spark = SparkSession.builder().config(conf).getOrCreate()
    val df = spark.read.json(dataPath)
    df.createOrReplaceTempView("persons")

    val getProvince = udf((addr: String) => {
      try {
        val p = "^(.*省|.*自治区|.*市).*".r
        val p(province) = addr
        province
      }catch{
        case _ => ""
      }
    })
    val getAgeGroup = udf((age: Int) => {
      try {
        val g = (age/10) * 10
        if (g == 0){
          "1-9"
        } else {
          g.toString + "s"
        }
      } catch{
        case _ => ""
      }
    })
    spark.udf.register("getProvince", getProvince)
    spark.udf.register("getAgeGroup", getAgeGroup)
    spark.sql("select getProvince(BPLACE) as province, count(*) as total from persons group by province order by total desc")
      .repartition(1).write.json("./report/province")

    spark.sql("select SEX, count(*) as total from persons group by SEX order by total desc")
      .repartition(1).write.json("./report/sex")

    spark.sql("select getAgeGroup(AGE) as age_group, count(*) as total from persons group by age_group order by age_group")
      .repartition(1).write.json("./report/age-group")

    spark.stop
  }
}
