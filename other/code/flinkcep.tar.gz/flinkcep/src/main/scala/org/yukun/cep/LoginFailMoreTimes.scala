package org.yukun.cep

import org.apache.flink.api.scala.createTypeInformation
import org.apache.flink.cep.PatternSelectFunction
import org.apache.flink.cep.scala.CEP
import org.apache.flink.cep.scala.pattern.Pattern
import org.apache.flink.streaming.api.TimeCharacteristic
import org.apache.flink.streaming.api.functions.timestamps.BoundedOutOfOrdernessTimestampExtractor
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.streaming.api.windowing.time.Time

import java.text.SimpleDateFormat
import java.util
import java.util.Date

case class LoginEvent(userId: Long, ip: String, event: String, ts: Long)

object LoginFailMoreTimes {
  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment
    env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime)
    env.setParallelism(1)

    val eventStream = env.readTextFile("./data/login.log")
      .map(line => {
        val fields=line.split(",");
        LoginEvent(
          fields(0).trim.toLong,
          fields(1).trim,
          fields(2).trim,
          fields(3).trim.toLong)
      }).assignTimestampsAndWatermarks(new BoundedOutOfOrdernessTimestampExtractor[LoginEvent](Time.seconds(20)) {
      override def extractTimestamp(t: LoginEvent): Long = t.ts * 1000L
    }).keyBy(_.userId);

    // pattern
    val failPattern = Pattern
      .begin[LoginEvent]("begin").where(_.event == "fail")
      .timesOrMore(3)
      .greedy
      .within(Time.seconds(10))

    val patternStream = CEP.pattern(eventStream, failPattern)

    patternStream.select(new PatternSelectFunction[LoginEvent, String] {
      override def select(map: util.Map[String, util.List[LoginEvent]]): String = {
        var iterator = map.get("begin").iterator()
        var res = ""
        while (iterator.hasNext) {
          var fail = iterator.next()
          res += fail.userId.toString + " login fails at: " + (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(new Date(fail.ts * 1000)) +"\n"
        }
        res + "=============="
      }
    }).print()

    env.execute("Login Fails 3 or more then 3 times in 10 seconds")
  }
}
