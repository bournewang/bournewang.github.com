package org.yukun.cep

import org.apache.flink.api.scala.createTypeInformation
import org.apache.flink.cep.PatternSelectFunction
import org.apache.flink.cep.scala.CEP
import org.apache.flink.cep.scala.pattern.Pattern
import org.apache.flink.streaming.api.TimeCharacteristic
import org.apache.flink.streaming.api.functions.timestamps.BoundedOutOfOrdernessTimestampExtractor
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.streaming.api.windowing.time.Time

import java.text.SimpleDateFormat
import java.util
import java.util.Date

//case class LoginEvent(userId: Long, ip: String, event: String, ts: Long)

object LoginFailWithin3Seconds {
  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment
    env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime)
    env.setParallelism(1)

    val eventStream = env.readTextFile("./data/login.log")
      .map(line => {
        val fields=line.split(",");
        LoginEvent(
          fields(0).trim.toLong,
          fields(1).trim,
          fields(2).trim,
          fields(3).trim.toLong)
      }).assignTimestampsAndWatermarks(new BoundedOutOfOrdernessTimestampExtractor[LoginEvent](Time.seconds(5)) {
        override def extractTimestamp(t: LoginEvent): Long = t.ts * 1000L
      }).keyBy(_.userId);

      // pattern
    val failPattern = Pattern
      .begin[LoginEvent]("begin").where(_.event == "fail")
      .next("next").where(_.event == "fail")
      .within(Time.seconds(3))

    CEP.pattern(eventStream, failPattern)
      .select(new PatternSelectFunction[LoginEvent, String] {
      override def select(map: util.Map[String, util.List[LoginEvent]]): String = {
        val firstFail = map.get("begin").iterator().next()
        val lastFail = map.get("next").iterator().next()
        "user " + firstFail.userId.toString +
          " login failed at " + (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(new Date(firstFail.ts * 1000)) +
          " and " + (new SimpleDateFormat("HH:mm:ss")).format(new Date(lastFail.ts * 1000))
      }
    }).print()

    env.execute("Login Fail in 3 seconds CEP")
  }
}
