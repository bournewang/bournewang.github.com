---
title: "「SF-PLF」4 HoareAsLogic"
subtitle: "Programming Language Foundations - Hoare Logic as a Logic"
layout: post
author: "Hux"
header-style: text
hidden: true
tags:
  - SF (软件基础)
  - PLF (编程语言基础)
  - Coq
  - 笔记
---

TBD
